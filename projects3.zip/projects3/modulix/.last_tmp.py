def lins(msg):
    """
    => cria um texto personalizado com linhas
    param msg; mensagem do texto
    return nao retorna nada 
    """
    tam = len(msg)+2
    print('•'*tam)
    print(f' {msg}')
    print('•'*tam)


lins('....tempo....')


#------------------------//--------------------------#

def strint(num):
      return num


list=[]
list=input('horas: ')

a = strint(list)
print(a)


'''
def strint(num=0,sig=':',num2=0):
    num = int(num)
    sig = str(sig)
    num2 = int(num2)
    
    n = input(num)
    s = input(sig)
    n2 = input(num2)
      
    a = print(num,sig,num2)
    

   
#print(f'{strint()}',end=' ')
b = strint(input(),input(),input())
print(b)
'''