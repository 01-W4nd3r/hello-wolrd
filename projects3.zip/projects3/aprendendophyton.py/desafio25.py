print(' ')
print('=====|DESAFIO 25|=====')
'''crie um programa que leia o nome de 
uma pessoa e diga se ela tem "silva" 
no nome'''
print(' ')
name = str(input('digite seu nome: '))
print(' ')
print('este nome tem o nome "silva" em alguma \nparte dele ? : ')
print('silva' in name.lower())