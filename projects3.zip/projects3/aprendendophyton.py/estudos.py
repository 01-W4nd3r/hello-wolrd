#pylint:disable= unmatched ')' (<unknown>, line 3)
print(' ')
print('======estudos======')
p = (1,0,2)
t = sum(p)
print(f'tupla {p}: {t}')

p = [1,0,2]
t = sum(p)
print(f'lista {p}: {t}')

l = {}
p = [1,0,2]
l['n'] = p
t = sum(l['n'])
print(f'dicionario {l}: {t}')
