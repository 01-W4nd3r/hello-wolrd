print(' ')
print('=====|DESAFIO 32|=====')
'''leia um programa que leia um ano 
qualquer e mostre se ele e bixesto''' 
print(' ')
from datetime import date
ano = int(input(' qual ano você quer analizar ? digite 0 \n para colicar seu ano atual : '))
print(' ')
if ano == 0:
    ano = date.today().year

if ano%4 == 0 and ano % 100 !=0:
    print('o ano {} e bissexto'.format(ano))
else:
    print('o ano {} nao e bisexto'.format(ano))
