print(' ')
print('=====|DESAFIO 61|=====')
'''
Refaça o desafio 51, lendo o primeiro termo e 
a razão de uma PA, mostrando os 10 primeiros 
termos da progressao usando a estrutura while.
'''
print(' ')
p = int(input('primeiro termo: '))
r = int(input('razao: '))
c = 1
while c < 11:
    p+=r
    print(f'{p}',end=' ')
    c+=1

print(' ')
