print(' ')
print('=====|DESAFIO 17|=====')
'''
faça um programa que leia o 
comprimento do cateto oposto e do 
cateto adjacente de um triangulo 
retangulo. 
calcule e mostre o 
comprimento da hipotenusa

Ex:. o quadrado da ipotenusa e igual 
a soma dos quadrados dos catetos'''
#Hipotenusa2 = 
#Cateto oposto2 + Cateto adjacente2
print(' ')
co = float(input('tamanho do cateto oposto: '))
ca = float(input('tamanho do cateto adjacente: '))
hi = (co**2 + ca**2)**(1/2)
print(' ')
print('o tamanho da hipotenusa e igaul a cateto \noposto {}² mais cateto adjacente {}² \nque igual a {:.1f} '.format(co, ca, hi))
