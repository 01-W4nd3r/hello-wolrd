print(' ')
print('=====|DESAFIO 41|=====')
'''
a confederação nacional de natação 
precisa de um programa que leia o 
ano de nacimento de um atleta e 
mostre sua categoria de acordo 
com sua idade:

- ate 9 anos: mirim
- ate 14 anos: infantil
- ate 19 anos: junior
- ate 20 anos: senior
- acima: master
'''
print(' ')
from datetime import date
a = int(input('ano de nacimento ? : '))
idd = date.today().year - a
print(' ')
if idd <= 9:
    print('sua idade e {} e sua categoria e mirim '.format(idd))
elif idd <= 14 and idd > 9:
    print('sua idade e {} e sua categoria e infantil '.format(idd))
elif idd <= 19 and idd > 14:
    print('sua idade e {} e sua categoria e junior '.format(idd))
elif idd <= 20 and idd > 19:
    print('sua idade e {} e sua categoria e senior '.format(idd))
else:
    print('sua idade e {} e sua categoria e master '.format(idd))
print(' ')
print('___fim___')
