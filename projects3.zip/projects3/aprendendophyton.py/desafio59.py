print(' ')
print('=====|DESAFIO 59|=====')
'''
Crie um programa que leia dois valores e 
mostre um menu na tela:

[1]somar 
[2]multiplicar 
[3]maior 
[4]novos numeros 
[5]sair do programa 
'''
print(' ')
o = 0
from time import sleep
n = int(input('digite um valor: '))
m = int(input('digite mais um valor: '))
print(' ')
while o != 5:
    print(' ')
    print('[1]somar \n[2]multiplicar \n[3]maior \n[4]novos numeros \n[5]sair do programa ')
    o = int(input('----> escolha uma opiçao: '))
    print(' ')
    if o == 1:
        print('o resultado de {} + {} e {} '.format(n, m, n+m))
    elif o == 2:
        print('o resultado de {} x {} e {} '.format(n, m, n*m))
    elif o == 3:
        if n > m:
            print('{} e maior que {} '.format(n, m))
        elif n < m:
            print('{} e maior que {} '.format(m, n))  
    elif o == 4:
        n = int(input('digite um valor: '))
        m = int(input('digite mais um valor: '))
        print(' ')
print('fechando programa... !' )
sleep(1)
print(' ')

