print(' ')
print('=====|DESAFIO 36|=====')
'''escreva um programa para aprovar o 
empréstimo bancário para a compra de 
uma casa. 

o programa vai perguntar o 
valor da casa. 

o salário do comprador. 

e em quantos anos ele vai pagar.

calcule o valor da prestação mensal. 

sabendo que ela nao  pode exceder 30% 
do salario ou então o empréstimo 
sera negado'''
'''
valor da casa: 200000
valor do salario: 1500   
valor anual a pagar: 30
'''
print(' ')
casa = float(input('qual e o valor da casa ? : '))
sal = float(input('qual e o valor do seu salário ? : '))
ano = float(input('em ate quantos anos voce pretende \npagar ? : '))
pms = (casa / 12) / ano
pct = sal * (30 / 100)  
print(' ') 
if pms > pct:
    print('R${:.2f} seu empréstimo bancário foi \nnegado por exceder "30%" de seu salario ! '.format(pms))
elif pms <= pct:
    print('seu empréstimo bancário foi aceito ! \ne o valor mensal a pagar e de R${:.2f} '.format(pms))   
else:
    print(' ')
print(' ')

       
print('___fim___')


