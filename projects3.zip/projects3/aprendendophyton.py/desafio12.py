print(' ')
print('=====|DESAFIO 12|=====')
#fassa um algaritimo que leia o preço 
#de um produto e mostre seu novo preço. 
#com 5% de desconto.
print(' ')
a = float(input('preço: '))
b = a-((5*a)/100)
print(' ')
print('seu produto que custa {}R$ na \npromoção com 5% desconto ele vai \ncustar {:.2f}R$ '.format(a, b))