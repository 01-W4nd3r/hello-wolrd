print(' ')
print('=====|DESAFIO 68|=====')
'''
Faça um programa que jogue par ou impar com o computador.
0 jogo só sará interrompido quando o jogador PERDER. 
mostrando o total de vitórias consecutivas que ele 
conquistou no final do jogo.
'''

print(' ')
from random import randint
soma = cont = c = 0 
while True:
    print(' ')
    computador = randint(1,10)
    compjogou = computador
    c+=1
    print(f'             [{c}]              ')
    print('_'*30)
    n = int(input('escolha um número de 1 a 10: '))
    player = str(input('player: [par/impar] ')).lower()
    print('-'*30)
    cont+=1 
    soma = computador + n
    if player == 'par':
        computador = 'impar'
    elif player == 'impar':
        computador = 'par'
    if player == 'par' :
        if soma%2 == 0:                
            print(f'computador: {computador} \ncomputador : {compjogou} \n...     player ganhou ')
            print('_'*30)
    if player == 'impar':
        if soma%2 != 0:
            print(f'computador: {computador} \ncomputador : {compjogou} \n...     player ganhou ')    
            print('_'*30)
    if player == 'impar':
        if soma%2 == 0:
            print(f'computador: {computador} \ncomputador : {compjogou} \n...     computador venceu ')
            break
            print('_'*30)
    if player == 'par':
        if soma%2 != 0:
            print(f'computador: {computador} \ncomputador : {compjogou} \n...    computador venceu ' )    
            break
            print('_'*30)          
print(' ')
print(f'voce ganhou {cont} antes de perder ')
print(' ')

