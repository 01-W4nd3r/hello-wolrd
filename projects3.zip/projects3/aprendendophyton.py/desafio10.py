print(' ')
print('=====|DESAFIO 10|=====')
#crie um programa que leia quanto 
#dinheiro uma pessoa tem na carteira 
#e mostre quantos dolares ela pode 
#compra.

#obs:. considerando que a cotaçao do 
#dolar esta : U$$ 1.00 = 3.27 - 5.06
print(' ')
c = float(input('R$: '))
d = c / 5.06
e = c / 5.54
i = c / 0.043
l = c / 6.60
f = c / 5.40
o = c / 321.05

print('UR$ {:.2f} \nEU$ {:.2F} \nIN$ {:.2f} \nlb$ {:.2f} \nFC$ {:.2F} \nO$ kg {:.2f}'.format(d, e, i, l, f, o))
print(' ')