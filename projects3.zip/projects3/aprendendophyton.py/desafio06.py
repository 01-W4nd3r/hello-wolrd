print(' ')
print('=====|DESAFIO 6|=====')
print(' ')
#crie um algoritmo que leia um numero e 
#mostre seu dobro triplo e raiz quadrada
n = int(input('digite um numero: '))
d = n*2
t = n*3
r = n**(1/2)
print(' ')
print('o dobro e: {} \no triplo e: {} \na raiz e: {:.2f}' .format(d, t, r))