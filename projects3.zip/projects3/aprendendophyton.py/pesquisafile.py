l = [15,7,27,39,78,12,106]
print('' '')
p=int(input('digite um valor a procurar: '))
achou=False
x=0
while x < len(l):
    if l[x] == p:
        achou = True
        break
    x+=1
if achou:
    print(f'{p} achado na posiçao {x}')
else:
    print(f'{p} não encontramos' )