print(' ')
print('=====|DESAFIO 7|=====')
print(' ') 
#desenvolva um programa que leia as 
#duas notas de um aluno, calcule 
#e mostre sua média 
p = float(input('sua primeira nota: '))
s = float(input('sua segunda nota: '))
d = (p+s)/2
print(' ')
print('sua media de notas e: {:.1f}' .format(d,))