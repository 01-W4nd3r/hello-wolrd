print(' ')
print('=====|DESAFIO 31|=====')
'''desenvolva um programa que pergunte a 
distância de uma viagem em km. 
calcule o preço da passagem.

cobrando R$0.50 por km para viagem de 
ate 200km e R$0.45 para viagens mais 
longa''' 
print(' ')
dist = int(input(' a viajem tem quantos km ? '))
menor = dist * 0.50
maior = dist * 0.45
print(' ')
if dist <=200:
    print(' o preço dessa viagem sera {:.2f}'.format(menor))
else:
    print(' o preço da sua viagem sera {:.2f} '.format(maior))
print(' ')    
print('__fim__')