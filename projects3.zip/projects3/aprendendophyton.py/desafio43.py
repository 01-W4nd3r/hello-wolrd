print(' ')
print('=====|DESAFIO 43|=====')
'''
desenvolva uma logica que leia o peso 
e a altura de uma pessoa. calcule seu 
status. de acordo com a tabela abaixo:
'''

print(''' abaixo de 18.5: abaixo do peso
 entre 18.5 e 25: peso ideal
 25 ate 30: sobrepeso
 30 ate 40: obesidade
 acima de 40: obsidade mórbida''')

print(' ')
peso = float(input('quel seu peso ? : '))
altura = float(input('qual e sua altura ? : '))
imc = peso / (altura * altura) 
print(' ')
if imc < 18.5:
    print('seu "IMC" e {:.2f} voce esta abaixo do \npeso ideal ! '.format(imc))
elif imc > 18.5 and imc < 25:
    print('seu "IMC" e {:.2f} voce esta no \npeso ideal  ! '.format(imc))
elif imc > 25 and imc < 30:
    print('seu "IMC" e {:.2f} voce esta asima do \npeso ideal  ! '.format(imc))
elif imc > 30 and imc < 40:
    print('seu "IMC" e {:.2f} voce esta com \nobesidade ! '.format(imc))
else:
    print('seu "IMC" e {:.2f} voce esta com \nobesidade morbida ! '.format(imc))    

print(' ')
print ('___fim___')


