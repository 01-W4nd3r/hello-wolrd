print(' ')
print('=====|DESAFIO 57|=====')
'''
Faça um programa que leia o sexo de uma 
pessoa, mas só aceite os valores 'M' ou 'f'. 
Casso esteija errado peça a digitaçao 
novamente ate ter um valor correto 
'''
print(' ')
print('qual e o seu sexo ?')
print(' ')
s = str(input('digite seu sexo [M/F]: ')).strip().upper()[0]
while  s not in 'fFmM':    
    s = str(input('dados invalidos digite novamente: ')).strip().upper()[0]
print(' ')
print('sexo {} validado com sucesso '.format(s))
print(' ')
'''
 if s != m and s != f
'''