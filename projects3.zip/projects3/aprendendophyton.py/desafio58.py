print(' ')
print('=====|DESAFIO 58|=====')
'''
Melhore o jogo do DESAFIO 28 onde o 
computador vai "pensar" em um número 
entre 0 a 10 so que agora o jogador 
vai tentar adivinha ate acertar, mostrando 
no final quantos palpites foram nessesarios
'''
from random import randint
from time import sleep
print(' ')
print('><•'*14)
print(' vou pensar em um numero entre 0 e 5 \n tente adivinhar')
print('><•'*14)
print(''' 
	''')
tentativas = 0
computador = randint (0, 10)
n = int(input('escolha um numero de 0 a 10 : '))
print(' ')
while n != computador:
    if n > computador:       
        n = int(input('menos... tente mais uma vez. \nqual e o seu palpite ?: ')) 
        tentativas += 1
    elif n < computador:
        n = int(input('mais... tente mais uma vez. \nqual e o seu palpite ?: '))
        tentativas += 1
print(' ')
if n == computador:
    print(' ')
    print('parabens voce GANHOU com {} tentativas !'.format(tentativas))
    print(' ')
print('__fim__')