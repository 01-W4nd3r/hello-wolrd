print(' ')
print('=====|rascunho 94|=====')
'''
crie um programa que leia nome, sexo e idade de varias 
pessoas, guardando os dados de cada pessoa em um 
dicionário e todos os dicionarios em uma lista no 
final mostre. 
A) quantas pessoas foram cadastradas 
B) a media de idade do grupo. 
C) uma lista com todas as mulheres. 
D) uma lista com todas as pessoas com idade a cima da 
media
'''
print(' ') 
galera = list() 
dis = dict()
dados = list()
soma=media=0
m=cont=media=mulheres=0
while True:
    dis.clear()
    cont+=1
    dis['nome'] = str(input('nome: '))
    while True:
        dis['sexo'] = str(input('sexo: [M/F] ')).lower()[0]
        if dis['sexo'] not in 'fm':
            print("ERRO... a letra incorreta escreva somente M ou F")
        else:
            break
    dis['idade'] = int(input('idade: '))
    soma += dis['idade']
    galera.append(dis.copy())
    while True:
        b = str(input('quer comtinuar? [S/N]  ')).lower()[0]
        if b in 'sn':
            break
            print('ERRO... escreva somente S ou N')
    if b == 'n':
        break
            
media = soma / cont           
print('-='*21)
print(dados) 
print(f'O grupo tem {cont} pessoas.')
print(f'a media de idade e de {media:5.2f} anos. ')
print(f'as mulheres cadastradas foram ',end=' ')
for p in galera:
    if p['sexo'] in 'f':
        print(f'{p["nome"]}.',end=' ')
print(' ')
print('as pessoas acima da idade foram ')
for c in galera:
    if c['idade'] >= media:
        for k, v in c.items():
            print(f'{k} = {v};',end=' ')        
print('<<encerrado>>')
print(' ')