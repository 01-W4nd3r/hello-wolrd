print(' ')
print('=====|DESAFIO 97|=====')
'''
faça um programa que tenha uma funçao chamada escreva(), 
que receba um texto qualquer como parâmetro e mostre 
uma mensagem com tamanho adapitavel.
'''
print(' ') 
def escrever(msg):
    tam = len(msg)+4
    print('-'*tam)
    print(f'  {msg}')
    print('-'*tam)
escrever('wander')
escrever('Alves')
escrever('moreira')
escrever('junior')
escrever('19')   
print(' ')