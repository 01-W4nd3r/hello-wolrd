print(' ')
print('=====|DESAFIO 84|=====')
'''
faça um programa que leia nome e peso de varias 
pessoas guardando tudo em uma lista. 
No final mostre: 

A) quatas pessoas foram cadastradas 
B) uma lista com as pessoas mais pesadas 
C) uma lista com as pessoas maia leves

'''
print(' ') 
dados=[]
princ=[]
mai=0
men=0
cont=0
while True:
    cont+=1
    dados.append(str(input('nome: ')))
    dados.append(int(input('peso: ')))
    if len(princ) == 0:
        mai=men=dados[1]
    else:
        if dados[1] > mai:
            mai=dados[1]
        if dados[1] < men:
            men=dados[1]
    princ.append(dados[:])
    dados.clear()
    pas=str(input('quer continuar [s/n]: ')).lower()    
    if pas == 'n':
        break 
print(f'foram cadastradas {cont} pessoas') 
print(f'o maior peso foi de {mai}kg peso de ',end='')
for p in princ:
    if p[1] == mai:
        print(f'{p[0]}',end=' ')
print(f'o \nmenor peso foi de {men}kg peso de ',end='')
for p in princ:
    if p[1] == men:
        print(f'{p[0]}',end=' ')
print(' ')