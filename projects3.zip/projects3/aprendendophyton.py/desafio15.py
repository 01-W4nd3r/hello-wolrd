print(' ')
print('=====|DESAFIO15|=====')
#escreva um programa que pergunte a 
#quantidade de km percorrido por um 
#carro alugado e a quantidade de dias 
#pelos quais ele foi alugado calcule 
#o preço a pagar. sabendo que o carro 
#custa R$60 por dia e R$0.15 por km 
#rodado.
print(' ')
km  =  float ( input ( 'Quantos km foram percorridos: ' ))
dias  =  int ( input ( 'Quantos dias foram o aluguel: ' ))
total =  (km  *  0.15) + (dias * 60)
print('valor total a pagar {} '.format(total))

print(' ')