print(' ')
print('=====|DESAFIO 100|=====')
'''
Faça um programa que tenha uma lista chamada números e 
duas funções chamadas sorteia() e somapar(). a 
primeira função vai sortear 5 números e vai colocalos 
dentro da lista e a segunda função vai mostrar a 
soma entre em todos os valores pares sorteados pela 
função anterior
'''
print(' ') 
numeros=list()
from time import sleep
from random import randint 
par=list()
soma=0
def sortear(lista):
    print(f'sorteando 5 valores da lista:',end=' ')
    for c in range(1,6):
        num=randint(1,10)
        print(f'{num}',end=' ',flush=True)
        sleep(0.4)
        lista.append(num)    
    print('pronto!')    
                
def somapar(lista):
    soma=0
    print(f'somando os valores pares de {numeros} temos',end=' ')
    for c in lista:
        if c % 2 == 0:
            soma+=c
    print(soma)
        
numeros=list()
sortear(numeros)
somapar(numeros)      
print(' ')