print(' ')
print('=====|DESAFIO 96|=====')
'''
faça um programa que tenha uma funçao chamada área(), 
que recebe as dimensões de um terreno retangular 
(largura e comprimento) e mostre a area do terreno
'''
print(' ') 
def area():
    lar = float(input('LARGURA (m): '))
    com = float(input('COMPRIMENTO (m): '))
    area = lar*com
    print(f'a area de um terreno {lar}x{com} e de {area}m²')
print('CONTROLE DE TERRENO')
print('-'*22)
area()
print(' ')