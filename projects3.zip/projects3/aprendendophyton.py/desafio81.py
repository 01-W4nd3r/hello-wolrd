print(' ')
print('=====|DESAFIO 81|=====')
'''
crie um programa que vai ler vários números e colocar 
em uma lista. 
Depois disso mostre:  
A) quantos números foram digitados 
B) a lista de valores ordenado de forma decrescente 
C) se o valor 5 foi digitado e esta ou nao na lista.
'''
print(' ')
cont=0
lista=[]
while True:
    lista.append(int(input('digite um valor: ')))
    pos=str(input('quer continuar [s/n]: ')).lower()
    cont+=1
    if 5 in lista:
        five='foi'
    elif 5 not in lista:
        five='nao foi'    
    if pos == 'n':
        print(f'foram digitados {cont} valores')
        break
lista.sort(reverse=True)
print(f'os valores na forma decrescente \nsao {lista} ')
print(f'o valor 5 {five} adicionado lista')

print(' ')