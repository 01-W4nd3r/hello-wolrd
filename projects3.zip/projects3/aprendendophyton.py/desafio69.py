print(' ')
print('=====|DESAFIO 69|=====')
'''
Crie um programa que leia a idade e o sexo 
de várias pessoas. A cada pessoa cadastrada. 
o programa deverá perguntar se o usuário 
quer ou não continuar. No final. mostra:
    
A) quantas pessoas tem mais de 18 anos.
B) Quantos homens Foram cadastrados.
C) Quantas mulharas tem menos de 20 anos.
'''
tot18=totman=fm20=0
while True:
    i = int(input('idade ? : '))
    s = ' '
    while s not in 'mf':
        s = str(input('seu sexo [m/f]: ')).lower()           
    if i >= 18:
       tot18+=1
    if s == 'm':
       totman+=1
    if i < 20 and s == 'f':
        fm20+=1       
    resp = ' '
    while resp not in 'sn':    
        resp = str(input('quer continuar [s/n]: ')).lower()   
    if resp == 'n':
        break
print(' ')
print(f'pessoas maiores de 18: {tot18} \nhomems cadastrados: {totman} \nmulheres com menos de 20 anos: {fm20} ')    
print('acabou')    
'''
print(' ')

cont = m = idd =  0
while True:
    print(' ')
    print('______CADASTRE UMA PESSOA_______')
    print(' ')
    i = int(input('qual e a sua idade: '))
    while i < 0 or i > 100:
        print('idade invalida tente novamente')
        i = int(input('qual e a sua idade: '))
        if i >= 18:
            idd+=1          
    s = str(input('qual e o seu sexo[m/f]: ')).lower()   
    while s not in 'mf':
        print('sexo invalido tente novamente')
        s = str(input('qual e o seu sexo[m/f]: ')).lower()
        if s == 'm':
            m+=1
        if s == 'f' and i < 20:
            cont+=1
    n = str(input('quer continuar [sim/nao] ?: ')).lower()    
    while n not in 'simnao':
        print('resposta invalida tente novamente')    
        n = str(input('quer continuar [sim/nao] ?: ')).lower()
        print(' ')
        if n == 'sim':
            w = True
        elif n == 'nao':
            break

print(f'ah {m} homens cadastrados \n{cont} mulheres com menos de 20 anos \n{idd} pessoas maiores de 18 anos ')    
print(' ')
'''
