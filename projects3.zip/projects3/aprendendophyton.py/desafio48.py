print (' ')
print('=====|DESAFIO 48|=====')
'''
Faça um programa que calcule a soma
entre todos os números impares que 
são multiplos de tres e que se 
encontram no intervalo de 1 ate 500.

total: 500
impares: 250
pares: 250
''' 
print(' ')
soma = 0
count = 0
for c in range (1,500,2):
    if c%3 == 0:
        count = count+1
        soma = soma+c
        
        
print('o resultado das soma de todos os {} \nnumeros e {} '.format(count,soma))
print(' ')
