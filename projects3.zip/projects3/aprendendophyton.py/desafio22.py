print(' ')
print('=====|DESAFIO 22|=====')
'''crie um programa que leia o nome 
completo de uma pessoa e mostre:

*o nome com todas as letras maiusculas

*o nome com todas as letras minúsculas

*quantas letras ao todo (sem comsidera os espaços)

*quantas letras tem o primeiro nome'''

print(' ')
name = str(input('digite seu nome completo: ')).strip()
#dividido = name.split()
print(' ')
print('seu nome em maiusculo fica: {}'.format(name.upper()))
print('seu nome em minusculo fica: {}'.format(name.lower()))
print('seu nome completo tem {} letras'.format(len(name) - name.count(' ')))
print('seu primeior nome tem {} letras'.format(name.find(' ')))
print(' ')


#upper(): transforma toda a frase em maiuscula
#lower(): transforma toda a frase em minuscula
#strip(): remove os espaços desnessesario ma frase
#len[]: mostra a quantidade de caracteres
#split(): desmenbra a frase de usando os espaços entre ela 
