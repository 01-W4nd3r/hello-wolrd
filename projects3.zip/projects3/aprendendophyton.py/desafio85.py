print(' ')
print('=====|DESAFIO 85|=====')
'''
crie um programa onde o usuário possa digitar sete 
valores numericos e cadastre-os em uma lista unica 
que mantenha separado os valores pares e impares no 
final mostre os valores pares e impares em ordem 
crescente
'''
print(' ')
sec =[[],[]]
num = 0


for n in range(1,8):
    num=int(input(f'digite o {n}º valor: '))
    if num%2 == 0:
        sec[0].append(num)
    else:
        sec[1].append(num)
sec[0].sort()
sec[1].sort()       
print(f'os números pares são {sec[0]} ')
print(f'os números inpares sao {sec[1]} ')
print(' ')