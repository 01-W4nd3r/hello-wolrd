print(' ')
print('=====|DESAFIO 83|=====')
'''
crie um programa onde o usuário digite uma expressão 
qualquer que use parenteses. 
Seu aplicativo devera analisar se a expressão passada 
esta com parentes abertos ou fechados na orden 
correta.
'''
print(' ')
expr = str(input('digite a expressão: '))  
pilha = []  
for simb in expr: 
    if '('or')' not in simb:
        print('nao a () nessa epreçao') 
        break
    if simb  == '(':  
        pilha.append('(') 
    elif simb == ')':  
        if len(pilha) > 0:  
            pilha.pop() 
        else: 
            pilha.append(')') 
            break 
if len(pilha) == 0:
    print('sua espreçao esta valida !') 
else: 
    print('sua espreçao esta errada ! ')
print(' ') 
'''
lista=[] 
while True:
    exp=str(input('digite uma expressão: '))
    if '(' in exp and ')' in exp:
        lista.append(exp)
        print(lista)
        break       
    else:
        print('....nao a () em sua frase !')
'''
