print(' ')
print('=====|DESAFIO 88|=====')
'''
faça um programa que ajude um jogador da mega sena a 
cria palpites. O programa vai perguntar quantos jogos 
serao gerados e vai  sortear 6 numeros entre 1 a 60 
para cada jogo cadastrado, tudo em uma lista composta
'''
print(' ')  
from random import randint #importa a biblioteca que ira gera os números 
from time import sleep # importa a biblioteca que iria deixar o tempo mais lento para geralas
lista = list()
jog = list()
tot=1
num=int(input('quantos jogos voce quer fazer ?: '))# pergunta a quantidade de jogos que o usuário quer fazer 
while tot <= num:# limita a quantidade de jogos gerados pelo gosto do usuário 
    cont = 0
    while True: #coloca os números sorteados em uma lista de 6 numeros 
        seq = randint(1,60)
        if seq not in lista:
            lista.append(seq)
            cont+=1
        if cont == 6:
            break
    lista.sort()# organiza os números em ordem cresente 
    jog.append(lista[:])
    lista.clear()
    tot+=1
for i, l in enumerate(jog):# organiza os números em uma tabela e mostra quantos jogos foram feitos
    print(f'jogo {i+1}: {l}')
    sleep(0.3)
print('-----------|boa sorte|-----------')
    
print(' ')




