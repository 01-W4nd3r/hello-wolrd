print(' ')
print('=====|DESAFIO 76|=====')
'''
crie um programa que tenha uma tupla unica com nomes 
de produtos e seus respectivos preços, na sequência.

No final, mostre uma listagem de preços, organizado 
os dados em forma tabular.
18
'''
print(' ')
prod=('Lapis',
	1.75,
	'borracha',
	2.00,
	'caderno',
	15.90,
	'estojo',
	25.00,
	'transferidor',
	4.20,
	'compasso',
	9.99,
	'mochila',
	120.32,
	'canetas',
	22.30,
	'livro',
	34.90)
print('-'*36)
print(f'{"listagem de preços":^35}')
print('-'*36)
for pos in range(0,len(prod)):
    if pos%2==0:
        print(f'{prod[pos]:.<25}',end='.')
    else:
        print(f'R${prod[pos]:>7.2f}|')
print(' ')
print(' ')
print('-'*36)
print(f'{"ORIGINAL":^35}')  
print ('-'*36)
prod=('Lapis',1.75,'borracha',2.00,'caderno',15.90,'estojo',25.00,'transferidor',4.20,'compasso',9.99,'mochila',120.32,'canetas',22.30,'livro',34.90)
print(prod[0],end='.')
print(f'....................R$   {prod[1]}|')
print(prod[2],end='.')
print(f'.................R$    {prod[3]}|')
print(prod[4],end='.')
print(f'..................R$   {prod[5]}|')
print(prod[6],end='.')
print(f'...................R$   {prod[7]}|')
print(prod[8],end='.')
print(f'.............R$    {prod[9]}|')
print(prod[10],end='.')
print(f'.................R$   {prod[11]}|')
print(prod[12],end='.')
print(f'..................R$ {prod[13]}|')
print(f'{prod[14]}',end='.')
print(f'..................R$   {prod[15]}|')
print(f'{prod[16]}',end='.')
print(f'....................R$   {prod[17]}|')
print(' ')