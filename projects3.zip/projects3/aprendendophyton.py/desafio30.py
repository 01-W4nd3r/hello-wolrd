print(' ')
print('=====|DESAFIO 30|=====')
'''crie um programa que leia um numero 
inteiro e mostre na tela se ele e par 
ou impar'''
print(' ')
n = int(input('digite um numero: '))
#par == 2 * n
#inpar = 2 * n + 1
print(' ')
if n%2 == 0 :
    print('este numero e "par" ')
else:
    print('este numero e "impar" ')
print(' ')
print('___fim___')    