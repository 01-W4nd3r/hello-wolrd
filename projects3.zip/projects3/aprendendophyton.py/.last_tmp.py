print(' ')
print('=====|DESAFIO 13|=====')
#faça um algaritimo que leia o salario 
#de um funcionario e mostre seu novo 
#salario com 15% de aumento.
print(' ')
a = float(input('salario: '))
b = a * (100+15)/100
print(f'novo salario: {b} ')