print(' ')
print('=====|DESAFIO 93|=====')
'''
crie um programa que gerencie o aproveitamento de um 
jogador de futebol. O programa vai ler o nome do 
jogador e quantas partidas ele jogou depois vai ler 
a quantidade de gols feitos em cada partida no final 
tudo isso sera guardado em um dicionário incluindo o 
total de gols feitos durante o campeonato
'''
print(' ')  
from random import randint
dis = dict()
gols = list()
total = 0
dis['nome'] = str(input('nome do jogador: '))
partidas = int(input(f'quantas partidas {dis["nome"]} jogou ?: '))
for c in range(1,partidas+1):
    gols.append(int(input(f'    quantos gols na partida {c} ? ')))
    total+=sum(gols)
    dis['total'] = total
    dis['gols'] = gols
print('-='*21)
print(dis)
print('-='*21)
for k, v in dis.items():
    print(f'{k}: {v}')
print(f"total de gols: {total}")
print('-='*21)
print(f" o jogador {dis['nome']} jogou {partidas} partidas.")
for v, c in enumerate(gols):
    	print(f"    => na partida {v+1}, fez {c} gols.") 
print(f'foi um total de {dis["total"]} gols')
print(' ')