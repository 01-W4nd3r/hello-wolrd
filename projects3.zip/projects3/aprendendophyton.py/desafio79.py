print(' ')
print('=====|DESAFIO 79|=====')
'''
crie um programa onde o usuário possa digitar vários 
valores numéricos e cadastre-os em uma lista. 
caso o numero ja exista la dentro ele nao sera 
adicionado. 
No final. Serão exibidos todos os valores unicos 
digitados em orden cresente
'''
print(' ') 
lista=[]
print('numeros repetidos serão deletados \nautomaticamente !')
print(' ')
while True:
    num=(int(input('digite um valor: ')))
    pros=str(input('quer continuar [s/n]: ')).lower()
    if pros=='n':
        break
    if num not in lista:
        lista.append(num)
print(f'{sorted(lista)}')    
 
print(' ')