print(' ')
print('=====|DESAFIO 86|=====')
'''
crie um programa que cria uma matriz de dimensão 3x3 
e preencha com valores lidos pelo teclado  no final 
mostre a matris na tela com a formatação correta
'''
print(' ') 

matriz=[[0,0,0],[0,0,0],[0,0,0]] 
for l in range(0,3): 
   for c in range(0,3): 
      matriz[l][c]=int(input(f'digite um valor para [{l}, {c}]: ')) 
print(' ')
for l in range(0,3): 
   for c in range(0,3): 
      print(f'[{matriz[l][c]:^5}]',end=' ') 
   print(' ')
   
   
print('-='*21)

'''
pri=[[],[],[],[],[],[],[],[],[]] 
nun= 0
for c in range(1,10):
    num=int(input(f'digite o {c} valor: '))
    if c < 2 : 
        pri[0].append(num)
    if c > 1 and c < 3:
        pri[1].append(num)
    if c > 2 and c < 4 : 
        pri[2].append(num)
    if c > 3 and c < 5:
        pri[3].append(num)
    if c > 4 and c < 6 : 
        pri[4].append(num)
    if c > 5 and c < 7:
        pri[5].append(num)
    if c > 6 and c < 8 : 
        pri[6].append(num)
    if c > 7 and c < 9:
        pri[7].append(num)
    if c > 8:
        pri[8].append(num)

print(' ')
print(f'{pri[0]}',end='')
print(f'{pri[1]}',end='')
print(f'{pri[2]}',end='')
print(f'\n{pri[3]}',end='')
print(f'{pri[4]}',end='')
print(f'{pri[5]}',end='')
print(f'\n{pri[6]}',end='')
print(f'{pri[7]}',end='')
print(f'{pri[8]}',end='')
print(' ')
'''