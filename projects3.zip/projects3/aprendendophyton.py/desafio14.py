print(' ')
print('=====|DESAFIO14|=====')
#comverta graus celsios para graus 
#Fahrenheit
print(' ')
c = float(input('graus celsius: '))
f = (c * 9/5) + 32 
k = c + 273,15 
print(' ')
print(' {}°c e igual a {}°c fahrenheit é \n e igual a {}°c kelvi'.format(c, f, k))