print(' ')
print('=====|DESAFIO 104|=====')
'''
crie um programa que tenha uma funçao leiaint(), que 
vai funcionar de forma semelhante ao input() do 
phyton,so que fazendo a validaçao para aceitar 
somente um valor numerico.  
Ex: n=leiaint('digite um numero')
'''

# MEU 
print(' ')  
def leiaint(txt):   
    txt = str(txt)
    n = input(txt)
    while not n.isnumeric():         
        print('\033[0;31merro. digite somente um valor numerico!\033[m')
        n = input(txt)
        if n.isnumeric():
            break
    return n
     
a = leiaint('digite um numero: ')
print(f'voce digitou o numero {a} !')  
print(' ')



# PROFESSOR 
'''
def leiaint(msg):
    ok = False
    valor = 0
    while True:
        n = str(input(msg))
        if n.isnumeric():
            valor = int(n)
            ok = True
        else:
            print('\033[0;31merro. digite somente um valor numerico!\033[m')
        if ok:
            break
    return valor 


a = leiaint('digite um numero: ')
print(f'voce digitou o numero {a} !') 
'''
     