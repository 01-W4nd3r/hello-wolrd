print(' ')
print('=====|DESAFIO 77|=====')
'''
Crie um programa que tenha uma tupla com varias 
palavras (nao usar acentos). Depois disso voce 
deve mostrar para cada palavra, quais sao as suas 
vogais.

na palavra {tup} temos:
'''
print(' ')  
tup=('aprender', 'programar', 'línguagem', 'phyton', 'curso gratis', 'estudar', 'praticar', 'trabalhar', 'mercado', 'programador', 'futuro')
vog=('a','e','i','o','u')
ten=' '
for c in tup:
    print(f'\nna palavra {c} temos:',end=' ')
    for a in vog:
        if a in c:
            print(f'{a}',end=' ') 

print(' ')
