print(' ')
print('=====|DESAFIO 102|=====')
'''
crie um programa que tenha uma função fatorial() que 
receba dois Parametros: o primeiro que indique o 
numero a calcular e o outro chamado show que sera o 
valor logico (opcional) indicando se sera mostrado ou 
nao na tela o processo de calculo do fatorial
'''
print(' ')
def fatorial(num,show=False):
    """
    -> calcula o fatorial de um numero.
    num; numero a ser calculado. 
    show; parâmetro (opicional) para mostrar o calculo.
    return; retorna o resultado do valor de num.
    """
    f = 1
    for c in range(num,0,-1):
        if show:
            print(f'{c}',end='')
        if c > 1:
            print('x',end='')
        else:
            print('=',end='')
        f*=c
    return f

#print(fatorial(3,True))  
print(' ')
help(fatorial)