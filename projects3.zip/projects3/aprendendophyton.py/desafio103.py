print(' ')
print('=====|DESAFIO 103|=====')
'''
faça um programa que tenha uma funçao chamada ficha(), 
que receba dois Parametros opçionais: o nome de um 
jogador e quantos gols ele marcou. 

O programa deve ser capaz de mostrar a ficha do 
jogador mesmo que algum dado nao tenha sido imformado 
corretamente

'''
print(' ') 
def ficha(nam='<desconhecido>',gol=0):
    """
    -> mostra a ficha de um jogador.
    nam; nome do jogador.
    gol; gols do jogador.
    return; nao retorna nada
    """
    print(' ')
    print('ficha de jogadores')
    print('-='*21)
    print(f'nome do jogador: {nam} \ngols feitos: {gol} ')
    print('-='*21)

n = str(input('nome do jogador ?: '))
g = str(input('gols feitos ?: '))

if g.isnumeric():
    g = int(g)
else:
    g=0
if n.strip == ' ':
    ficha(gol=g)
else:
    ficha(n,g)
print(' ')