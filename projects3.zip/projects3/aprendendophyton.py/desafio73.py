print(' ')
print('=====|DESAFIO 73|=====')
'''
crie uma tupla preenchida com 20 primeiros colocados 
da tabela do campeonato brasileiro de futebol. 
Na ordem de colocação. Depois mostre:

A) apenas os 5 primeiros colocados.
B) os últimos 4
Colocados da tabela.
C) uma lista com os times em ordem alfabetica.
D) em que posição na tabela esta o time da 
chapecoense.
'''
print('•='*21) 
tabela=('Corinthians','Palmeiras','São Paulo','atlético-MG','Botafogo','Santos','Fluminense','Coritiba','America-MG','Avaí','Internacional','Atlético-PM','Bragantino','Flamengo','Goias','Cuiabá','Atlético Goianiense','Juventude','Ceará','Fortaleza')
print(f'\033[0;33mos 5 primeiros colocados:\033[m {tabela[0:5]}')
print('•='*21)
print(f'\033[0;33mos últimos 4:\033[m {tabela[16:]}')
print('•='*21)
print(f'\033[0;33mtimes em ordem alfabetica:\033[m {sorted(tabela)}')
print('•='*21)
print(f'''\033[0;33mque posição na tabela esta o time da 
São Paulo:\033[m {tabela.index("São Paulo")+1}''')
print('•='*21)
print(' ')