print(' ')
print('=====|DESAFIO 92|=====')
'''
crie um programa que leia nome, ano de nascimento e 
carteira de trabalho e cadastre-os (com idade) em um 
dicionário se por acaso o CTPS for diferente de zero 
o dicionário recebera também o ano  de contratação e 
o salário. 
Calcule e acrescente alem da idade com quantos anos a 
pessoa vai se aposentar
'''
print(' ')
from datetime import date
dis = dict()
nome = str(input('nome: '))
ano = int(input('ano de nacimento: '))
carteira = int(input('carteira de trabalho (0 nao tem): '))
hoje = date.today().year
idade = hoje - ano 
dis['nome'] = nome
dis['ano'] = ano
dis['carteira'] = carteira
dis['idade'] = idade

if carteira == 0:
    print('-='*21)
    print(f'nome  {nome}  \nidade {idade}  \nctps  {carteira}')
if carteira != 0:
    contrato = int(input('ano da contratação: '))
    salario = int(input('salario: R$'))
    dis['contrato'] = contrato
    dis['salario'] = salario
    aposs = hoje - contrato
    if aposs < 35:
        aposentar = (35 - aposs) + idade
        dis['aposentar'] = aposentar
        print('-='*21)      
        print(f"nome  {dis['nome']}  \nidade {dis['idade']}  \nctps {dis['carteira']} \ncontratação  {dis['contrato']} \nsalario  {dis['salario']} \naposentadoria  {dis['aposentar']} ")           
print(' ')
print(dis)