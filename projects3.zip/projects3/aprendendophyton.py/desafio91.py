print(' ')
print('=====|DESAFIO 91|=====')
'''
crie um programa onde 4 jogadores joguem um dado e 
tenha resultados aleatórios. Guarde esses resultados 
em um dicionário. No final, coloque esse dicionário 
em ordem sabendo que o vencedor tirou o maior número 
no dado.
'''
print(' ') 
from random import randint
from time import sleep
from operator import itemgetter
sleep(0.5)
jogo = dict()
for c in range(1,5):
    jogo[f"jogador{c}"]=f"{randint(1,6)}" 
ranking = list()
print('valores sorteados')
for c, x in jogo.items():
    print(f' 0 {c}  caiu no {x}')   
    sleep(1)
ranking = sorted(jogo.items(), key=itemgetter(1), reverse=True)
print(' ')
print('-='*21)
print('RANK DOS JOGADORES')
print(' ')
for i, v in enumerate(ranking):
    print(f'    {i+1}° lugar {v[0]} com {v[1]} ')
    sleep(1)

    
    
