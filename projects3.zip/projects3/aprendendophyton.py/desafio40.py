print(' ')
print('=====|DESAFIO 40|=====')
'''
crie um programa leia duas nostas de 
um aluno e calcule sua média. 
mostrando uma mensagem nó final de 
acordo com a média atingida:

- media abaixo de 5.0: reprovado

- média entre 5.0 e 6.9: recuperação

- media 7.0 ou superior: aprovado
'''
print(' ')
n1 = float(input('primeira nota: '))
n2 = float(input('segunda nota: '))
n3 = float(input('terceiro nota: '))
m = (n1 + n2 + n3) / 3
print(' ')
if m < 5.0:
    print('voce foi reprovado com a media de {:.2f}'.format(m))
elif m >= 7.0:
    print('voce foi aprovado com a media {:.2f} '.format(m))
else:
    print('voce ficou de recuperação com a media {:.2f} '.format(m))
