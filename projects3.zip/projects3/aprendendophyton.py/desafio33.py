print(' ')
print('=====|DESAFIO 33|=====')
'''fassa um programa que leia tres 
números e mostre qual e o maior e 
qual e o menor'''
print(' ')
a = int(input('digite um número: '))
b = int(input('digite mais um numero: '))
c = int(input('digite um ultimo numero: ') )

print(' ')
maior = a
menor = a
if b > a and b > c:
    maior = b
if c > a and c > b:
    maior = c

if b < a and b < c:
    menor = b
if c < a and c < b:
    menor = c
print(f'esse e o maior {maior}')
print(f'esse e o menor {menor}')