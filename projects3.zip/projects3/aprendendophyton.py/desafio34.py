print(' ')
print('=====|DESAFIO 34|=====')
'''escreva um programa que pergunte 
qual e o salario de um funcionário e 
calcule o valor do seu aumento 

para salario superiores a
R$1.250.00. calcule um aumento de 10%

para inferiores ou iguais o aumento 
e de 15% '''
print(' ')
salario = float(input('digite seu salario: '))
dez = salario * (100+10)/100
quinze = salario * (100+15)/100
print(' ')
if salario > 1250.00:
    print('seu salario e R${:.2f} depois do almento \nde 10% ele ficara R${:.2f} '.format(salario, dez))
else:
    print('seu salario e R${:.2f} depois do almento \nde 15% ele ficara R${:.2f} '.format(salario, quinze))    
