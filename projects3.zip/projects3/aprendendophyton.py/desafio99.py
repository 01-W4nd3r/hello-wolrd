print(' ')
print('=====|DESAFIO 99|=====')
'''
Faça um programa que tenha uma funçao chamada maior(), 
que receba vários parâmetros com valores inteiros, 
seu programa tem que analizar todos os valores e 
dizer qual deles e o maior.
'''
print(' ') 
from time import sleep
def maior(*num):
    maior = cont = 0
    print('analizando os valores passados...')
    for c in num: 
        sleep(0.1)
        print(f'{c}',end=' ',flush=True)
        sleep(0.1)
        if cont == 0:
            maior=c
        else:
            if c > maior:
                maior=c
        cont+=1
    print(f'foram imformados {cont} valores ao todo o maior valor imformado \nfoi {maior}',flush=True)
    print('=-'*21)

maior(7,8,9,4,0,3)
maior(2,7,5,3) 
maior(0,7)
maior(9,5,8,3,7,2,0,2)
maior()
print(' ')