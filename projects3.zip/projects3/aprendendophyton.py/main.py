y = float(input('valor do produto ?: '))
x = int(input('porcento de desconto ?: '))
w = x/100*y
z = y-w
print('o valor {} com desconto de {}% é {}'.format(y, x, z))