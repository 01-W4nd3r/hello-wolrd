print(' ')
print('=====|DESAFIO 24|=====')
'''crie um programa que leia o nome de 
uma cidade e diga se ela começa ou 
não com o nome "santo"'''
print(' ')
name = str(input('nome da cidade: ')).strip()
#print(name.find('santo'))
print(' ')
print('esta cidade tem "santo" no nome?: ')
print(name[:5].upper() == "SANTO")
