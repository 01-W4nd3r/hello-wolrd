print(' ')
print('=====|DESAFIO 62|=====')
'''
Melhore o DESAFIO 61, perguntando para o 
usuario se ele quer mostrar mais alguns 
termos. O programa encerra quandi ele 
disser que quer mostrar 0 termos.
'''
print(' ')
p = int(input('primeiro termo: '))
r = int(input('razao: '))
termo = p
count = 1
total = 0
mais = 10
while mais != 0:
    total= total + mais
    while count <= total:
        print(f'{termo} ->',end=' ')
        termo+=r
        count+=1
    print('pausa')  
    mais = int(input('quantos termos voce quer mostrar a mais ? '))
print('a quantidade de termos mostrado foi {} '.format(total))    	
print(' ')

