print(' ')
print('=====|DESAFIO 72|=====')
'''
crie um programa que tenha uma tupla totalmente 
preenchido com uma contagem por extenso. do zero 
ate vinte.

Seu programa devera ler um número pelo teclado 
(entre 0 e 20) e mostra-lo por extenso.
'''
print(' ')  
number = ('zero','um','dois','tres','quatro','sinco','seis','sete','oito','nove','dez','onze','doze','treze','quatorze','quinze','dezesseis','dezessete','dezoito','dezenove','vinte')
n = int(input('digite um numero entre 0 e 20: '))
while n >= 0 or n <= 20 :
    if n < 0 or n > 20:
        print(' ')
        n = int(input('tente novamente.................... \n.....digite um numero entre 0 e 20: '))
    else:
        break       
print(f'voce digitou o numero: {number[n]} ')     
print(' ')