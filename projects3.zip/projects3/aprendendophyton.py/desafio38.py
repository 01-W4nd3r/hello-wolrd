print(' ')
print('=====|DESAFIO 38|=====')
'''
ecreva um programa que leia dois 
números inteiros e compare-os. 
mostrando na tela uma mensagem:

- o primeiro valor e o maior
- o segundo valor e o maior
- nao existe valor maior. os dois 
são iguais
'''
print(' ')
a = int(input('primeiro numero: '))
b = int(input('segundo numero: '))
maior = a 
print(' ')
if a > b:
    print('o PRIMEIRO numero e o maior')
elif b > a:
    print('o SEGUNDO numero e o maior')     
else:
    print('nao existe valor maior os dois sao iguais')
 