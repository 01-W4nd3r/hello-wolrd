print(' ')
print('=====|DESAFIO 49|=====')
'''
Refaça o desafio 009, mostrando a tabuada 
de um numero que o usuário escolher, so que 
agora utilizando um laço for.
''' 
print(' ')  
n = int(input('digite um numero: '))
print('-'*41)
for c in range(1,11):
    print('• {} x {} = {}  |'.format(n,c,n*c))
print('-'*41)