print(' ')
print('=====|DESAFIO 55|=====')
'''
Faça um programa que leia o peso de cinco 
pessoas. No final. Mostre qual foi o maior 
e o menor peso lidos.
'''
print(' ') 
maior = 0
menor = 0
for p in range(1,6):
    peso = float(input('peso da {}ª pessoa: '.format(p)))
    if p == 1:
        maior = peso
        menor = peso
    else:
        if peso > maior:
            maior = peso
        if peso < menor:
            menor = peso
print('o maior peso lido foi de {}kg '.format(maior))
print('o menor peso lido foi de {}kg '.format(menor))
print(' ')
