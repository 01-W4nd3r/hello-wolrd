print(' ')
print('=====|DESAFIO 63|=====')
'''
Escreva um programa que leia um número 
inteiro qualquer e mostre na tela os n 
primeiros elementos de uma sequencia de 
Fibonacci.    
Exe:. 0 1 1 2 3 5 8

Para saber o proximo numero da sequência e so 
somar os dois numeros anteriores
Exe:. 0+1=1
1+1=2
1+2=3
2+3=5
3+5=8
5+8=13
0 1 1 2 3 5 8 13
'''
print(' ')
n = int(input('quantos termos voce quer mostrar ? '))
t1 = 0
t2 = 1
print('{} -> {} ->'.format(t1, t2),end=' ')
cont = 3

while cont <= n:
    t3 = t1+t2
    print('{} ->'.format(t3),end=' ')
    cont+=1
    t1 = t2
    t2 = t3
print(' ')
