print(' ')
print('=====|DESAFIO 78|=====')
'''
Faça um programa que leia 5 valores numericos e 
guarde-os em uma lista no final mostre qual foi o 
maior e o menor valor digitado e as suas respectivas 
posiçoes na lista
'''
print(' ') 
lista=[]
mai=0
men=0
for c in range(0,5):
    lista.append(int(input(f'digite um valor para a posição {c}: ')))
    if c == 0:
        mai=men=lista[c]
    else:
        if lista[c]>mai:
            mai=lista[c]
        if lista[c]<men:
            men=lista[c]      
print(f'voce digitou os valores {lista} ')
print(f'o maior valor digitado foi {mai} nas posiçoes ',end='')
for i,v in enumerate(lista):
    if v == mai:
        print(f'{i}... ',end='')
print(f'\no menor valor digitado foi {men} nas posiçoes ',end='')
for i,v in enumerate(lista):
    if v == men:
        print(f'{i}... ',end='')
print(' ')