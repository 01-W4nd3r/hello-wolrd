#int - inteiros 
#7  -4  0  9876

#float - reais ou pontos flutuantes
#4.5  0.076  -15.223  7.0 

#bool - valores lógicos ou boleanos 
#True False

#str - e valores caracteres ou strings
#'ola'  '7,5'  ' ' 

#* BIBLIOTECA DO (n.is)

#- isupper: verifica se esta em maiúsculo

#- isalnum: verificar se esta em 
# alfanumérico

#- isalpha: verifica se e alfabético

#- isdigit: verifica se e os caracteres 
# são dígitos

#- isdecimal: verificar se todos caracteres 
# são decimis

#- isnumeric: verufica se oq caracteres 
# são numéricos

#- isidentifier: veifica se a string 
# for um identificador válido nó phyton

#- islower: verifica se esta em minusculo

#- isprintable: verifica se todos os 
# caracteres da string forem imprimiveis 
# ou se a string estiver vazia

#- isspace: veifica se é um espaço 
# verifica se houver apenas caracteres 
# de espaço em branco na string

#- istitle: verifica se a sequência 
# for uma sequência com títulos 

#DESAFIO 04
#fasa um programa que leia algo pelo 
#teclado e mostre na tela o seu tipo 
#primitivo e todas as informações 
#possíveis sobre ele 
print(' ')
print('=====| DESAFIO 04 |=====')
print(' ')
n = input('digite algo: ' )
print(' ')
print('o tipo primal e' ,type(n))
print('e numerico ?',n.isnumeric())
print('e alfabetico ?',n.isalpha())
print('e alfanumerico ?',n.isalnum())
print('e um digitos ?',n.isdigit())
print('e capitalisado ?',n.istitle())
print('tem espaço na estring ?',n.isspace())
print('a strinh esta vazia ?',n.isprintable())
print('esta em maiusculo ?',n.isupper())
print('esta em minusculo ?',n.islower())
print('tem no phyton ? ?',n.isidentifier())
#print('o seu resultado e {}'.format(n))
#print(type(s))
