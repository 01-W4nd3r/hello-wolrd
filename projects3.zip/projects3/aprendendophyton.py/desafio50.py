print(' ')
print('==============|DESAFIO 50|===============')
'''
Desenvolva um programa que leia seis números 
inteiros e mostre a soma apenas daqueles que 
forem pares. Se o valor digitado for impar, 
desconsidere-o
'''
print(' ')
count = 0
soma = 0
for c in range(1,7):
    num = int(input('digite o {} valor: '.format(c))
    	if num %2 == 0:
        soma += num
        cont += 1
print('voce imformou {} numero pares e a soma foi {} '.format(cont, soma))       
print(' ')