print(' ')
print('=====|DESAFIO 52|=====')
'''
Faça um programa que leia um número inteiro e 
diga se ele é ou não um numero primo
'''
print(' ')
n = int(input('digite um numero: '))
tot = 0
for c in range(1,n+1):
    if n%c == 0:
        tot +=1    
        print('\033[32m',end=' ')
    else:
        print('\033[31m',end=' ')           	
    print('{}'.format(c),end=' ')
print(' ')
print('\033[m o numero {} foi divisivel {}x '.format(n, tot),end=' ')
if tot == 2:
    print('o numero {} \n \033[32mE\033[m um numero primo'.format(n))
else:
    print('o numero {} \n \033[31mNÃO\033[m e um numero primo'.format(n))    
print(' ')