print(' ')
print('=====|DESAFIO 8|=====')
#escreva um programa que leia um 
#valor em metros e o exiba convertido 
#em centímetros e milímetros.
# 1m = 100cm = 1000mm
# 1cm = 10mm 
#obs:. quantos sentimentos tem 3 
#metros ? quantos milímetros tem 3 
#metros ?
print(' ')
m = float(input('metros: '))
k = 1000 / m
h = 100 / m
da =10 / m
d = 10 * m
c = 100 * m
n = 1000 * m
print('{:.1f}km \n{:.1f}hm \n{:.1f}dam \n{}m\n{:.0f}cm \n{:.0f}mm '.format(k, h, da, m, c, n))