print(' ')
print('======|DESAFIO 46|=====')
'''
Faça um programa que mostre na tela 
uma contagem regressiva para o 
estouro de fogos de artificio. Indo 
de 10 ate 0. Com uma pausa de 1 
segundo entre eles.
'''
print(' ')
from time import sleep
print('contagen regressiva para o ano novo')
print(' ')
for c in range(10,0,-1):
    sleep(1)
    print(c)
sleep(1)
print(' ')
print('feliz ano novo')
sleep(1)
'''
i = str(input('iniciar contagem ? : '))
f = sim
t = não
if i == f:
    for c in range(10,0,-1):
        print(c)
        print('feliz ano novo')
elif i == t:
    print('vamos deixar os fogos para o ano que vem ! ')   
else:
    print('...')
'''      
print(' ')