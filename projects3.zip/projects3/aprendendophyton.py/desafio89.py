print(' ')
print('=====|DESAFIO 89|=====')
'''
crie um programa que leia nome e duas notas de varios 
alunos e guarde tudo em um lista composta. 
No final mostre:
um boletim contendo a media de cada um e 
permita que o usuário possa mostra as notas de cada 
aluno individualmente
'''
print(' ')  
dados = list()
while True:
    nome = str(input('nome: ')) 
    nota1 = int(input('nota 1: ')) 
    nota2 = int(input('nota 2: '))
    media = (nota1+nota2)/2
    dados.append([nome,[nota1,nota2],media])
    pas=str(input('quer continuar [s/n]: ')).lower()
    if pas == 'n' :
        break
print('-='*21)
print(f'{"No":<4}{"NOME":<10}{"MEDIA":>7}')
print('-'*21)
for i,a in enumerate(dados):
    print(f'{i:<4}{a[0]:<10}{a[2]:>6.1f}')
while True:
    print('-='*21)
    opc=int(input('mostra notas de qual aluno \n(999 interrompe): '))
    if opc == 999:
        print('finalizando...')
        break
    if opc <= len(dados):
        print(f'notas de {dados[opc][0]} são {dados[opc][1]}')
#media = num(1) + num(2)
print(' ')