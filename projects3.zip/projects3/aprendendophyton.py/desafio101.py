print(' ')
print('=====|DESAFIO 101|=====')
'''
crie um programa que tenha uma funçao chamada voto() 
que vai receber como parâmetros o ano de nascimento de 
uma pessoa retornando um valor literal indicando se 
uma pessoa tem voto 
negado, Opicional ou obrigatório nas eleições.
'''
print(' ')  
from datetime import date
hoje = date.today().year
def voto():
    """
    fala se seu voto e obrigatorio, opicional ou nao vota
    
    """
    print('=-'*21)
    ano = int(input('em que ano você naceu ?: '))
    idade = hoje - ano
    if idade < 16:
        print(f"com {idade} anos não vota")
    elif idade >= 16 and idade < 18:
        print(f"com {idade} anos voto Opicional")
    elif idade >= 18 and idade <= 65:
        print(f"com {idade} anos voto obrigatorio")
    elif idade > 65:
        print(f"com {idade} anos voto opicional")
    print('=-'*21)

voto()
help(voto)
print(' ')