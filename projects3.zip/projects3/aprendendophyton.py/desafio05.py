print(' ')
print ('=====|DESAFIO 05|=====') 
#faça um programa que leia um número 
#inteiro e mostra na tela o seu sucesso 
#e seu antessesor
print(' ')
n = int(input('digite um número: ' ))
s = n +1
a = n -1
print('seu numero e: {} \no sucessor dele e: {} \no antecessor e: {}' .format(n, s, a))