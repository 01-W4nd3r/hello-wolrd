print(' ')
print('==============|DESAFIO 51|===============')
'''
Desenvolva um programa que leia o primeiro 
termo e a  razão de uma pa, no final, 
mostre os 10 primeiros termos dessa 
progressão.
'''
print(' ')
print('='*41)
print('          10 TERMOS DE UMA PA          ')
print('='*41)
print(' ')
p = int(input('primeiro termo: '))
r = int(input('razao: '))
d = p + (10-1)*r
for c in range(p,d+r,r):
    print(c)
print(' ')