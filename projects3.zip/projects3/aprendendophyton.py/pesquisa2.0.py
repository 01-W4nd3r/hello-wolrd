print('=====|comsulta produtos|=====')
print(' ')
tabela={'alface': 0.45,'batata': 1.20,'tomate': 2.30,
'feijao': 1.50,'barriga suina': 2560,
'barriga porco': 2650,}
while True:
    produto=str(input('digite o nome do produto, e fim para terminar:  ')).lower()
    if produto == 'fim':
        break
    if produto in tabela:
        print(f'{produto} cod: {tabela[produto]}')
    else:
        print('produto nao encontrado')