print(' ')
print('=====|DESAFIO 82|=====')
'''
crie uma progama que vai ler varios números e 
colocar em uma lista. 
Depois disso crie duas listas extras que vao contar 
apenas os valores pares e os 
valores impares digitados, Respectivamente.  
Ao final mostre o conteudo das tres listas geradas.
'''
print(' ') 
lista=[]
par=[]
impar=[]
while True:
    num=int(input('digite um valor: '))
    pas=str(input('quer continuar ?[s/n]: ')).lower()
    lista.append(num)
    if num%2==0:
        par.append(num)
    if num%2!=0:
        impar.append(num)
    if pas in 'n':
        break
print('=='*21)
print(f'os numeros digitados foram \n{lista} ')
print(f'os numeros pares digitados foram \n{par} ')
print(f'os numeros impares digitadoa foram \n{impar} ')
print(' ')