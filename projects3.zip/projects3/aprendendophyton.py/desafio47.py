print(' ')
print('=====|DESAFIO 47|=====')
'''
Crie um programa que mostre na tela 
todos os números pares que estão no 
inventário entre 1 e 50.
'''
print(' ')
from time import sleep
for c in range(2,51,2):
    sleep(1)
    print(c) 
   
print(' ')

