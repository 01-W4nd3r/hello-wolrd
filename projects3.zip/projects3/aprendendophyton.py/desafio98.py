print(' ')
print('=====|DESAFIO 98|=====')
'''
faça um programa que tenha uma funçao chamada contador(),  
que recebe tres parâmetros: inicio, fim e passo e 
realize a contagem seu programa tem que realizar 
tres contagens atraves da função criada 
A) de 1 ate 10 de 1 em 1 
B) de 10 ate 0 de 2 em 2 
C) uma contagem personalizada
'''
print(' ')
from time import sleep
def contador(ins,fim,pas):
    """
    -> faz uma contagem e mostra na tela.
    :param; ins: inicio da contagem
    :param; fim: fim da contagem
    :param; pas: passo da contagem
    :return: sem retorno 
    """
    if pas < 0:
        pas*=-1
    if pas == 0:
        pas = 1
    print(f'contagem de {ins} ate {fim} de {pas} em {pas}')
    if ins < fim:       
        for c in range(ins,fim+1,pas):
            print(f'{c}',end=' ',flush=True)
            sleep(0.2)
    else:
        for c in range(ins,fim-1,-pas):
            print(f'{c}',end=' ',flush=True)
            sleep(0.2)
    print('fim')
contador(1,10,1)
print('-'*24)
contador(10,0,2) 
print('~'*42)
print('agora e a sua vez de personalizar a \ncontagem !')
ins = int(input('inicio: '))
fim = int(input('fim: ')) 
pas = int(input('passo: '))   
contador(ins,fim,pas)
print(' ')