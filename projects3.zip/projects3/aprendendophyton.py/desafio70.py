print(' ')
print('{:=^42}'.format('|DESAFIO 70|'))
'''
Crie um programa qua leia o nome e o preço de vários 
produtos.0 programa deverá perguntar se o usuário 
vai continuar. No final, mostre:
A) Qual é o total gasto na compra.
B) Quantos produtos custam mais de R$1000.
C) Qual é o nome do produto mais barato.
'''

barato= ' '
tot=mais=menor=cont=0
while True:
    produto = str(input('nome do produto: '))
    preço = int(input('valor: R$'))
    tot+=preço
    cont+=1
    if preço > 1000:
        mais+=1
    if cont==1 or preço < menor:
        menor=preço
        barato=produto
    resp = ' '
    while resp not in 'sn':
        resp = str(input('quer continuar [s/n]: ')).lower().strip()[0]
    if resp == 'n':
        break
print(' ')
print(f'total: R${tot} \nprodutos mais caros que R$1.000: {mais} \no produto mais barato foi: {barato} \nque custou: R${menor} ')
print(' ')
print('{:-^42}'.format('fim do programa'))


'''
print(' ')
from time import sleep

mais = cont = pbarato = tot = barato = caro = p1 = p2 = 0
while True:  
    n = str(input('qual e o nome do produto ? : '))
    p = int(input('qual e o preço do produto ? : '))
    c = str(input('quer continuar ? [s/n]: ')).lower()    
    cont+=1
    tot+=p
    caro = p
    p1 = cont=1
    if p > 1000:
        mais+=1
    if barato > caro:
        caro = barato
        barato = caro
    elif barato < caro:
        barato = barato 
    if p1 > p2:
        pbarato = p2
    if p1 < p2:
        p2 = p1
        p1 = p2
        pbarato = p2 
    if c == 's':
        sleep(1)
    elif c == 'n':
        break
print(f'o total gasto na compra foi {tot} e {mais} produtos custam mais de R$1000 o nome do produto mais barato e {pbarato}')
'''
