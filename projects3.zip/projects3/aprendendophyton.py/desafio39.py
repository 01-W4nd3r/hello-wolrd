print(' ')
print('=====|DESAFIO 39|=====')
'''
faça um programa que leia o ano de 
nacimento de um jovem e informe. de 
acordo com sua idade:

- se ele ainda vai se alistar ao 
serviço militar.
- se e a hora de se alistar.
-se ja passou do tempo do alistamento.

seu programa também deverá o tempo 
que falta ou que passou do prazo.
'''
print(' ')
from datetime import date
nasc = int(input('qual seu ano de nacimento ? : '))
atual = date.today().year
idd = atual - nasc
print(' ')
print('quem nacel em {} tem {} anos em {} '.format(nasc, idd, atual))
print(' ')
if idd == 18:
    print('este e o ano do seu alistamento')
elif idd < 18:
    saldo = 18 - idd      
    print('seu alistamento sera daqui a {} ano '.format(saldo))
    ano = atual + saldo 
    print('seu alistamento sera em {} '.format(ano))
elif idd > 18:
    saldo = idd - 18
    print('seu alistamento foi a {} ano atras '.format(saldo))       
    ano = atual - saldo
    print('seu alistamento foi em {} '.format(ano))
else:
    print(' ')
    
    
