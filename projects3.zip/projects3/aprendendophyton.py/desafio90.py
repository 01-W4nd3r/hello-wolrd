print(' ')
print('=====|DESAFIO 90|=====')
'''
faça um programa que leia nome e media de um aluno. 
Guardando também a situação em um dicionário. 
No final, mostre o conteúdo da estrutura na tela
'''
print(' ') 
sit=dict() # cria o dicionário 
while True:
    nam=str(input('nome: ')) # pega o nome do usuário 
    media=float(input('nota: ')) # pega a nota do usuário 
    sit['nome']=nam # adiciona o nome dentro do dicionário 
    sit['media']=media # adiciona a nota ao dicionario
    if media >= 7: # verifica se a media e maior que 7
        stat="aprovado" # se a media for maior que 7 ele e aprovado     
        sit['stat']="aprovado"
    elif media >= 5 or media < 7:
        stat="recuperação"
        sit['stat']="recuperação"
    else: # verifica se a media e menor que 7 
        stat="reprovado"
        sit['stat']="reprovado"
    break
print('-='*21)
print(' ')
print(f" - nome e igual a {sit['nome']} \n - media e igual a {sit['media']} \n - situação e igual a {sit['stat']}")
print(' ')
