print(' ')
print('=====|DESAFIO 27|=====')
'''faça um programa que leia o nome 
completo de uma pessoa e mostre em 
seguida o primeiro e o ultimo nome 
separadamente

Ex:.ana maria de Souza
primeiro= ana
ultimo= souza'''
print(' ')
name = str(input('digite seu nome: '))
dividido = name.split()
print(' ')
print(f'primeiro nome: {dividido[0]}')
print('ultimo nome: {} '.format(dividido[len(dividido)-1]))