print(' ')
print('=====|DESAFIO 64|=====')
'''
Crie um programa que leia varios numeros 
inteiros pela teclado. 0 programa só vai 
parar quando o usuario digitar 999, que e 
a codiçao de parada. No final mostre quantos 
numeros foram digitados e qual foi a soma 
entre eles (DESCONSIDERANO O FLAG)
'''
print(' ')
cont = num = soma = 0
while num != 999:
    num = int(input('digite um numero[999para parar]: ')) 
    if num != 999:    
        soma+=num
        cont+=1
print('foram digitados {} numeros e a soma entre \neles e {} '.format(cont,soma))
print(' ')
print('---> fim do programa')

print(' ')