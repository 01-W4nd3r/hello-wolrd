print(' ')
print('=====|DESAFIO 42|=====')
'''
refaça o desafio 35 dos triangulos. 
acrescentando o recurso de mostrar 
que tipo de triangulo sera formado:

- equilátero: todos os lados iguais
- isosceles: dois lados iguais
- escaleno: todos os lados diferentes
'''
print('equilátero: todos os lados iguais\nisosceles: dois lados iguais\nescaleno: todos os lados diferentes')
print(' ')
a = float(input('primeura reta: '))
b = float(input('segunda reta: '))
c = float(input('terceira reta: '))
print(' ')
if (a+b > c) and (a+c > b) and (c+b > a):
    print('essas retas podem formar um triângulo  ')  
    if a == b and b == c:
        print('equilátero')
    elif a != b and b != c and a != c:
        print('escaleno')
    else:   
        print('isosceles')
else:
    print('essas retas nao podem formar um triângulo') 
print(' ')
print('___fim___')