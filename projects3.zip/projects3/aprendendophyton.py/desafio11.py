print(' ')
print('=====|DESAFIO 11|=====')
print(' ')
#faça um programa que leia a largura 
#e a altura de uma parede em metros.
 
#calcula a sua area e a quantidade de 
#tinta necessaria para pinta-la 
#sabendo que cada litro da tinta pinta 
#uma area de 2m².
a = float(input(' largura: '))
b = float(input(' altura: '))
m = a*b
t = m/2
print(' ')
print(' sua parede tem a dimençao de {}x{} e \n a area e de {}m² e voce precisa \n de {}L de tinta para pintar sua parede '.format(a, b, m, t))
