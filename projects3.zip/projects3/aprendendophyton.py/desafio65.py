print(' ')
print('=====|DESAFIO 65|=====')
'''
Crie um programa que leia varios numeros 
inteiros pelo teclado. No final da execução 
mostre a media entre todos os valores e 
qual foi o maior e o menor valores lidos. 0 
programa de e perguntar ao usuario se ele 
quer ou nao continuar a digitar valores.
'''
print(' ')

num = int(input('digite um numero: '))
run = str(input('quer continuar [s/n]: '))

run = 's'
cont = 1
soma = media = maior = menor = num
while run in 'sS':
    num = int(input('digite um numero: '))
    cont+=1
    soma+=num
    media = soma/cont
    if num > maior:
        maior = num
    elif num < menor:
        menor = num   
    run = str(input('quer continuar [s/n]: '))      
print('voce digitou {} a media deles e {:.2f} \no maior valor e {} e o menor foi {} '.format(cont,media,maior,menor))   
print(' ')
#media errada
# menor errado