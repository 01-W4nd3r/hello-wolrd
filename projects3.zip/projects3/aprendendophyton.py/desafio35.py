print(' ')
print('=====|DESAFIO 35|=====')
'''desenvolva um programa que leia o 
comprimento de tres retas e diga ao 
usuário se elas podem ou nao formar 
um triângulo''' 
print(' ')
a = float(input('primeura reta: '))
b = float(input('segunda reta: '))
c = float(input('terceira reta: '))
print(' ')
if (a+b > c) and (a+c > b) and (c+b > a):
    print('essas retas podem formar um triângulo !')
else:
    print('essas retas nao podem formar um triângulo !')    
