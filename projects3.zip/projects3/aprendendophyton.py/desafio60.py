print(' ')
print('=====|DESAFIO 60|=====')
'''
Faça um programa que leia um número qualquer 
mostre o seu fatorial. 

Exe:. 5! = 5x4x3x2x1 = 120
'''
print(' ')
n = int(input('digite um numero: '))
c = n
f = 1
print('calculando {}! = '.format(n),end=' ')
while c > 0:
    print('{}'.format(c),end=' ')
    print('x' if c > 1 else '=',end=' ')
    f *= c
    c -= 1
print('{}'.format(f),end=' ')
print(' ')


