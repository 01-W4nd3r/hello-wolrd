print(' ')
print('=====|DESAFIO 75|=====')
'''
Desenvolva um programa que leia quatro valores pelo 
teclado e guarde-os em uma tupla. No final, mostre:

A) quantas vezes apareceu o valor 9
B) em qual posição foi digitado o primeiro valor 3.
C) quais foram os números pares.
'''
print(' ')  
num1=int(input('digite um numero: '))
num2=int(input('digite outro numero: '))
num3=int(input('digite mais um numero: '))
num4=int(input('digite o último numero: '))

allnums=(num1,num2,num3,num4)
cont=0
par=0
print(' ')
print(f'o valor 9 aparece: {allnums.count(9)}x')
if 3 in allnums:
    print(f'o primeiro valor 3 apareceu\nna posição: {allnums.index(3)}')
else:
    print(f'o numero 3 nao aparece !')
print(f'os numeros pares foi:',end=' ')
for num in allnums:
    cont+=1
    if num%2 == 0:
        par=num
        print(f'{num}',end=' ')        
print(' ')