print(' ')
print('=====|DESAFIO 74|=====')
'''
crie um programa que vai gerar cinco números 
aleatório e colocar em uma tupla. 

Depois disso, mostre a listagem de números gerados e 
também indique o menor e o maior valor que estão na 
tupla.
'''
print(' ')
from random import randint 
randint
numeros=(randint(1,10),randint(1,10),randint(1,10),randint(1,10),randint(1,10))  
print(numeros)
print(f'maior: {max(numeros)}')
print(f'menor: {min(numeros)}')        
print(' ')