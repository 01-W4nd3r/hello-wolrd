print(' ')
print('=====|DESAFIO 67|=====')
'''
Faça um programa que mostra a tabuada de vários 
números, um de cada vez, para cada valor digitado 
pelo usuário. O programa será interrompido quando o 
número solicitado for
negativo -0
'''
'''
print('' '')
cont = 0
while True:
    print('_'*22)
    n = int(input('digite um numero: '))
    if n <= 0:
            break
    print('_'*22)
    print(' ')
    for c in range(1,11):
        cont+=1
        soma=n*cont
        print(f'{n}x{cont}= {soma}')
    cont=0
'''
print('________RESPOSTA 2________')

while True:
    print('_'*22)
    n = int(input('digite um numero: '))
    if n <= 0:
            break
    print('_'*22)
    print(' ')
    for c in range(1,11):
        print(f'{n}x{c}= {n*c}') 
           