print(' ')
print('=====|DESAFIO 29|=====')
	
'''escreva um programa que leia a 
velocidade de um carro.

se ele ultrapassar 80km/h mostre uma 
mensagem dizendo que ele foi multado.

a multa vai custar R$7.00 por cada 
km a sima do limite.'''
print(' ')
velo = int(input(' velocidade do carro: '))
asima = (velo * 7.00) - 560 
print(' ')
if velo >= 80:
    print('voce foi multado por esseço de velocidade e devera pagar uma multa de R${:.2f}!'.format(asima))
else:
    print('voce foi um bom motorista! tenha uma boa \nviagem ')  
print(' ')    
print('__fim__')
print(' ')