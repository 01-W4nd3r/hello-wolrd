print('\033[34m//'*21)
print('\033[32m=====|DESAFIO 6|=====')
print('\033[34m//'*21)
#crie um algoritmo que leia um numero e 
#mostre seu dobro triplo e raiz quadrada
n = int(input('\033[32mdigite um numero: '))
d = (n *2)
t = (n *3)
r = (n **2)
print('\033[34m//'*21)
print('\033[32mo dobro e: {} \no triplo e: {} \na raiz e: {}' .format(d, t, r))