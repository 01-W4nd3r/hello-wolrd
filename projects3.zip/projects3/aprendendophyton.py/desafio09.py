print(' ')
print('=====|DESAFIO 09|=====')
#faça um pograma que leia um numero 
#inteiro qualquer e mostre na tela a 
#sua tabuada completa.
print(' ')
n = int(input('tabuada do: '))
print(' ')
a = 1*n
b = 2*n
c = 3*n
d = 4*n
e = 5*n
f = 6*n
g = 7*n
h = 8*n
i = 9*n
j = 10*n                                                                
print('{} x 1: {}\n{} x 2: {}\n{} x 3: {}\n{} x 4: {}\n{} x 5: {}\n{} x 6: {}\n{} x 7: {}\n{} x 8: {}\n{} x 9: {}\n{} x 10: {} '.format(n,a, n,b, n,c, n,d, n,e, n,f, n,g, n,h, n,i, n,j,))


