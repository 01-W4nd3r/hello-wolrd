from time import sleep
print('helo...')
print('jo',end=' ')
sleep(2)
print('ken',end=' ')
sleep(2)
print('po!')
