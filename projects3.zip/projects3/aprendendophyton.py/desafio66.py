print(' ')
print('=====|DESAFIO 66|=====')
'''
Crie um programa que laia vários
números inteiros palo teclado. O programa só vai 
parar quando o usuário digitar o valor 999, que é a 
condição de parada. 
No final. 
mostra quantos números foram digitados a qual foi a 
soma entre eles (dasconsiderando o Flag)
'''
print(' ')
n = 0
cont = 0
soma = 0
while n != 999:
    soma+=n
    cont+=1
    n = int(input('digite um numero: '))
print(' ')    
print(f'o resultado da soma de todos os valores e {soma}')    
print(' ')
