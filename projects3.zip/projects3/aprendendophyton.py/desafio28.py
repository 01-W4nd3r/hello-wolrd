print(' ')
from random import randint
from time import sleep
print('=====|DESAFIO 28|=====')
'''escreva um programa que faça o seu 
computador "pensar" em um número 
inteiro de 0 a 5 e peça para o 
usuário tentar descobrir qual foi o 
número escolhido pelo computador.

o programa devera escrever na tela 
se o usuário venceu ou ou perdeu'''
print(' ')
print('><•'*14)
print(' vou pensar em um numero entre 0 e 5 \n tente adivinhar')
print('><•'*14)
print(''' 
	''')
n = int(input('escolha um numero de 0 a 5 : '))
computador = randint (0, 5)
print(''' 
	''')
print('PROCESSANDO...')
sleep(2)
print(' ')
print(f'RESULTADO: {computador}  ')
print(' ')
if n == computador:
    print('parabens voce GANHOU ! ') 
else:
    print('voce PERDEU mais sorte na proxima vez ! ')    
print(' ')
print('__fim__')