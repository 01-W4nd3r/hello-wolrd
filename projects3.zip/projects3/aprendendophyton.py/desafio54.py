print(' ')
print('=====|DESAFIO 54|=====')
'''
Crie um programa que leia o ano de nacimento 
de sete pessoas. No final, mostre quantas 
pessoas ainda nao atigiram a maioridade e 
quantas já são maiores. 
Considerando que a maioridade e de 21 anos a 
sima 
'''
print(' ') 
from datetime import date
maior = 0
menor = 0
atual = date.today().year
for c in range(1,8):
    n = int(input('em que ano a {}ª pessoa nacel: '.format(c)))
    idd = atual - n
    if idd > 21:   
        maior += 1
    elif idd < 21:
        menor += 1
print('ao todo tivemos {} pessoas maiores de idade'.format(maior))
print('e tambem tivemos {} pessoas menores de \nidade'.format(menor))      
print(' ')
