print(' ')
print('=====|DESAFIO26|=====')
'''crie um programa que leia uma frase 
pelo teclado e mostre:

*quantas vezes aparece a letra "a"

*em que posição ela aparece a primeira vez

*em que posição ela aparece a última vez'''

print(' ')
frase = str(input('escrava uma frase: ')).lower().strip()
print(' ')
print('a letra "a" aparece {} vezes na frase '.format(frase.count('a')))
print('ela aparece primeiro na posição {}'.format(frase.find('a')+1))
print('e aparece por ultim o na posição {}'.format(frase.rfind('a')+1))