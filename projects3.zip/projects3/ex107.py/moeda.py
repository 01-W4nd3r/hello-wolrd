print(' ')
print('=====|DESAFIO 107|=====')
'''
Crie um módulo chamado moeda.py que tenha as funções 
incorporadas almentar(), diminuir() dobro() e metade(). 
Faça também um programa que importe esse modulo e use 
alguma dessas funções
'''
print(' ')
  
def almentar(num,taxa=10):
    return num * (100+taxa)/100
 
    
def diminuir(num,taxa=5):
    return num * (100-taxa)/100
    

def dobro(num):
    return num*2
        

def metade(num):
    return num/2
    
    
print(' ')